#!/usr/bin/env python3
import os
from dotenv import load_dotenv #environment variable was created to store secret keys, this line of code is used to load the variable
load_dotenv()
secret_key1 = os.getenv("secretkey1")
secret_key2 = os.getenv("secretkey2")
def generate_key(text, key):

  key_length = len(key)
  repeated_key = key * (len(text) // key_length) + key[:len(text) % key_length]
  return repeated_key

def vigenere_encrypt(text, key):
  """
  Encrypts text using the Vigenere Cipher.

  Args:
      text: The text to be encrypted.
      key: The key to be used for encryption.

  Returns:
      A string containing the encrypted text.
  """
  encrypted_text = ""
  repeated_key = generate_key(text, key.lower())
  for i in range(len(text)):
    char = text[i]
    if char.isalpha():  # Check if character is alphabetic
      shift_value = ord(repeated_key[i]) - ord('a')
      new_index = (ord(char.upper()) - ord('A') - shift_value) % 26
      encrypted_text += chr(new_index + ord('A')) if char.isupper() else chr(new_index + ord('a'))
    else:
      encrypted_text += char  # Preserve non-alphabetic characters
  return encrypted_text



# Messages to encrypt
messages = [
  "hello",
  "world",
  "encryption",
  "someonecrackedmypassword",
  "poorsecurityhurtseveryone"
]

# Encrypt messages
encrypted_messages = [vigenere_encrypt(message, secret_key1) for message in messages]
# 
# Print results
print("Original Messages(First set):")
for message in messages:
  print(message)

print("\nEncrypted Messages:")
for message in encrypted_messages:
  print(message)
  
# Part 2: Decrypt messages using the second key
def generate_key(text, key):
    key_length = len(key)
    repeated_key = key * (len(text) // key_length) + key[:len(text) % key_length]
    return repeated_key

def vigenere_decrypt(cipher_text, keyword):
    key = generate_key(cipher_text, keyword)
    original_text = []

    for i in range(len(cipher_text)):
        if cipher_text[i].isalpha():  # Only decrypt alphabetic characters
            x = (ord(cipher_text[i].upper()) - ord(key[i].upper()) + 26) % 26
            x += ord('A')
            original_text.append(chr(x))
        else:
            original_text.append(cipher_text[i])  # Non-alphabetic characters remain the same

    return "".join(original_text)

messages2 = [
    "srnabepakm",
    "ciubrxhrvm",
    "cvsbcjtcmqqrt",
    "qfozfwvukqhlilrbfwoekgcaf",
    "uyeyhavkuzcjowofwmfplwjrskhmyssywwu"
]

decrypted_messages2 = [vigenere_decrypt(message, secret_key2) for message in messages2]

print("\nOriginal Messages (Second Set):")
for message in messages2:
    print(message)

print("\nDecrypted Messages:")
for message in decrypted_messages2:
    print(message)

# Part 2
# User input for direction, text, and secret key
direction = input("Enter 'e' to encrypt or 'd' to decrypt: ")
text = input("Enter the text: ")
secret_key = input("Enter the secret key: ")

# Perform encryption or decryption based on user input
if direction.lower() == 'e':
    result = vigenere_encrypt(text, secret_key)
    print("Encrypted message:", result)
elif direction.lower() == 'd':
    result = vigenere_decrypt(text, secret_key)
    print("Decrypted message:", result)
else:
    print("Invalid direction. Please enter 'e' or 'd'.")
    