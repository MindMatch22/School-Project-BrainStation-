#!/usr/bin/env python3
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes
import base64
import argparse
import logging
import traceback


# Set up a logger for the application using the module's name. Configure the logger to capture debug-level messages and above.
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

# Create a formatter that specifies the log message format, including the severity level, timestamp, logger name, and message.
formatter = logging.Formatter('%(levelname)s:%(asctime)s:%(name)s:%(message)s')

# Create a file handler to log messages to a file named 'encryption_app.log', capturing debug-level messages and above, and apply the formatter.
file_handler =  logging.FileHandler('encryption_app.log')
file_handler.setLevel(logging.DEBUG)
file_handler.setFormatter(formatter)

# Create a stream handler to output log messages to the console.
stream_handler = logging.StreamHandler()

# Add both the file handler and stream handler to the logger to log messages to both the file and the console.
logger.addHandler(file_handler)
logger.addHandler(stream_handler)


def derive_key(key):
    logger.debug('Generating a 32-byte (256-bit) key using PBKDF2')
    salt = b'salt1234'  # You should use a unique salt for each application
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=100000,  # Adjust the number of iterations as needed for your security requirements
        backend=default_backend()
    )
    logger.debug("Key generated sucessfully")
    return kdf.derive(key)


def encrypt(plaintext, key):
    key = derive_key(key.encode('utf-8'))
    cipher = Cipher(algorithms.AES(key), modes.CFB8(key[:16]), backend=default_backend())
    encryptor = cipher.encryptor()
    ciphertext = encryptor.update(plaintext) + encryptor.finalize()
    return base64.b64encode(ciphertext).decode('utf-8')

def decrypt(ciphertext, key):
    key = derive_key(key.encode('utf-8'))
    cipher = Cipher(algorithms.AES(key), modes.CFB8(key[:16]), backend=default_backend())
    decryptor = cipher.decryptor()
    try:
        ciphertext_bytes = base64.b64decode(ciphertext)
        plaintext = decryptor.update(ciphertext_bytes) + decryptor.finalize()
        return plaintext.decode('utf-8')
    except UnicodeDecodeError as e:
        logger.error(f"Error decoding ciphertext: {e}")
        return None


def main():
    parser = argparse.ArgumentParser(description="Simple AES Encryption and Decryption")
    parser.add_argument('mode', choices=['encrypt', 'decrypt'], help='Select "encrypt" or "decrypt" mode')
    parser.add_argument('-p', '--plaintext', help='Text to be encrypted or decrypted')
    parser.add_argument('-k', '--key', help='Encryption/Decryption key')
    parser.add_argument('-c', '--ciphertext', help='Text to be decrypted')

    args = parser.parse_args()
    
    
    if args.mode == 'encrypt':
        logger.info("Encryption in process")
        logger.debug(f"Length of plaintext: {len(args.plaintext)}") # Log debug messages showing the length of the plaintext and the key.
        logger.debug(f"Key length: {len(args.key)}")# These details are useful for developers to ensure the correct lengths are being used during the encryption process.
        if not args.plaintext or not args.key:
            logger.error("Both plaintext and key are required for encryption.") # Log an error message if either the plaintext or key is missing, indicating that encryption cannot proceed.
            return
        encrypted_text = encrypt(args.plaintext.encode('utf-8'), args.key)
        logger.info(f"Encrypted Text: {encrypted_text}") # Log the encrypted text at the INFO level to record the successful encryption of data.

        
    elif args.mode == 'decrypt':
        logger.info("Decryption in progress")# Log a info message indicating that the decryption process has started.
        if not args.ciphertext or not args.key:  
          logger.error("Error: Both ciphertext and key are required for decryption.") # Log an error message if either the ciphertext or key is missing, indicating that decryption cannot proceed.
          return
        decrypted_text = decrypt(args.ciphertext, args.key)
        logger.info(f"Decrypted Text: {decrypted_text}") # Log the decrypted text at the INFO level to record successful decryption.

if __name__ == "__main__":
   main()
